onoff = False
temp = 24
fanlevel = 2