import Globals
from MyLib import *
def main():
    # input
    
    # output
    # nyalakan AC
    TurnOnOff()
    # lihat status display ke-1
    Display()
    # naikkan suhu 2 kali supaya seperti contoh input/output
    TempUp()
    TempUp()
    # naikan level kipas 2 kali supaya seperti contoh input/output
    FanSpeed()
    FanSpeed()
    # lihat status display ke-2
    Display()

    #yang lain? Tulis sendiri bawah! Pastikan seperti input/output
    
    # naikkan suhu 2 kali supaya seperti contoh input/output
    TempUp()
    TempUp()
    # naikan level kipas 1 kali supaya seperti contoh input/output
    FanSpeed()
    # lihat status display ke-3
    Display()
    # Santuy Mode On
    PowerChill()
    # lihat status display ke-4
    Display()

#panggil main program disini
main()

if __name__ == "__main__":
    main()